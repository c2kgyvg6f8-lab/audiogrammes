@echo off
rem Ouvre l'outil Audiogrammes (garder ce fichier a cote de audiogrammes.ps1).
start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0audiogrammes.ps1"
