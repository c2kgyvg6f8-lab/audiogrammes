@echo off
rem Ouvre l'outil Audiogrammes dans sa petite fenetre, en haut a droite, toujours au premier plan.
rem Garder ce fichier dans le meme dossier que audiogrammes.ps1.
start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0audiogrammes.ps1"
