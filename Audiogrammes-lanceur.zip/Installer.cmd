@echo off
rem Installe l'outil Audiogrammes : icone sur le bureau + fenetre toujours au premier plan.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0audiogrammes.ps1" -Installer
