# Lanceur de l'outil Audiogrammes
# - ouvre l'outil dans une fenetre Chrome sans onglet (mode application)
# - la place en haut a droite de l'ecran principal, en petite taille
# - la garde au premier plan, au-dessus de Doctolib et des autres logiciels

$url = 'https://c2kgyvg6f8-lab.github.io/audiogrammes/?fenetre=1'
$titre = 'Audiogrammes - fenetre'

Add-Type -AssemblyName System.Windows.Forms
$zone = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$l = 340
$h = [Math]::Min(900, $zone.Height)
$x = $zone.Right - $l
$y = $zone.Top

$chrome = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LocalAppData\Google\Chrome\Application\chrome.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $chrome) {
  [System.Windows.Forms.MessageBox]::Show("Google Chrome est introuvable sur cet ordinateur.", "Audiogrammes") | Out-Null
  exit 1
}

Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public class FenetresAudio {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr apres, int x, int y, int cx, int cy, uint options);
  public static IntPtr Trouver(string titre) {
    IntPtr trouve = IntPtr.Zero;
    EnumWindows((h, l) => {
      if (!IsWindowVisible(h)) return true;
      var sb = new StringBuilder(256);
      GetWindowText(h, sb, 256);
      if (sb.ToString() == titre) { trouve = h; return false; }
      return true;
    }, IntPtr.Zero);
    return trouve;
  }
}
"@

$HWND_TOPMOST = [IntPtr](-1)
$fenetre = [FenetresAudio]::Trouver($titre)
if ($fenetre -eq [IntPtr]::Zero) {
  Start-Process -FilePath $chrome -ArgumentList "--app=$url", "--window-size=$l,$h", "--window-position=$x,$y"
  $limite = (Get-Date).AddSeconds(30)
  do {
    Start-Sleep -Milliseconds 300
    $fenetre = [FenetresAudio]::Trouver($titre)
  } until ($fenetre -ne [IntPtr]::Zero -or (Get-Date) -gt $limite)
}

if ($fenetre -ne [IntPtr]::Zero) {
  # SWP_SHOWWINDOW = 0x40 : position, taille, et toujours au premier plan
  [FenetresAudio]::SetWindowPos($fenetre, $HWND_TOPMOST, $x, $y, $l, $h, 0x40) | Out-Null
}
