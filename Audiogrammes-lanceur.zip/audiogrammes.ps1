# Outil Audiogrammes - lanceur pour Windows
#   audiogrammes.ps1 -Installer  : installation (une seule fois)
#   audiogrammes.ps1 -Surveiller : garde la fenetre de l'outil au premier plan (lance a l'ouverture de session)
#   audiogrammes.ps1             : ouvre l'outil (petite fenetre en haut a droite, sans onglet)
param([switch]$Installer, [switch]$Surveiller)

$url    = 'https://c2kgyvg6f8-lab.github.io/audiogrammes/?fenetre=1'
$appId  = 'aicmbmgdbigbmeiiecfphffliheccfdb'   # identifiant Chrome de l'application installee
$titre  = 'Audiogrammes - fenetre'
$verrou = 'Local\AudiogrammesPremierPlan'
$dossier = Join-Path $env:LOCALAPPDATA 'Audiogrammes'

Add-Type -AssemblyName System.Windows.Forms
Add-Type @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
public class FenetresAudio {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int index);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr apres, int x, int y, int cx, int cy, uint options);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  public static List<IntPtr> Trouver(string titre) {
    var liste = new List<IntPtr>();
    EnumWindows((h, l) => {
      if (!IsWindowVisible(h)) return true;
      var sb = new StringBuilder(256);
      GetWindowText(h, sb, 256);
      if (sb.ToString() == titre) liste.Add(h);
      return true;
    }, IntPtr.Zero);
    return liste;
  }
  // WS_EX_TOPMOST = 0x8 ; GWL_EXSTYLE = -20
  public static bool AuPremierPlan(IntPtr h) { return (GetWindowLong(h, -20) & 0x8) != 0; }
}
"@
$HWND_TOPMOST = [IntPtr](-1)

function Raccourci($chemin, $arguments, $icone) {
  $sh = New-Object -ComObject WScript.Shell
  $lnk = $sh.CreateShortcut($chemin)
  $lnk.TargetPath = (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
  $lnk.Arguments = $arguments
  $lnk.WindowStyle = 7
  $lnk.WorkingDirectory = $dossier
  if ($icone) { $lnk.IconLocation = $icone }
  $lnk.Save()
}

function Lancer-Surveillance {
  $m = $null
  if (-not [System.Threading.Mutex]::TryOpenExisting($verrou, [ref]$m)) {
    $ps1 = Join-Path $dossier 'audiogrammes.ps1'
    if (-not (Test-Path $ps1)) { $ps1 = $PSCommandPath }
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ps1`" -Surveiller"
  }
}

# ---------------------------------------------------------------- surveillance
if ($Surveiller) {
  $cree = $false
  $mutex = New-Object System.Threading.Mutex($true, $verrou, [ref]$cree)
  if (-not $cree) { exit 0 }          # deja en cours
  while ($true) {
    foreach ($h in [FenetresAudio]::Trouver($titre)) {
      if (-not [FenetresAudio]::AuPremierPlan($h)) {
        # SWP_NOSIZE 0x1 | SWP_NOMOVE 0x2 | SWP_NOACTIVATE 0x10
        [FenetresAudio]::SetWindowPos($h, $HWND_TOPMOST, 0, 0, 0, 0, 0x13) | Out-Null
      }
    }
    Start-Sleep -Milliseconds 700
  }
}

# ---------------------------------------------------------------- installation
if ($Installer) {
  New-Item -ItemType Directory -Force -Path $dossier | Out-Null
  Copy-Item -Force $PSCommandPath (Join-Path $dossier 'audiogrammes.ps1')
  $ico = Join-Path (Split-Path $PSCommandPath) 'audiogrammes.ico'
  if (Test-Path $ico) { Copy-Item -Force $ico (Join-Path $dossier 'audiogrammes.ico') }
  $ico = Join-Path $dossier 'audiogrammes.ico'
  $ps1 = Join-Path $dossier 'audiogrammes.ps1'
  $demarrage = [Environment]::GetFolderPath('Startup')
  Raccourci (Join-Path $demarrage 'Audiogrammes - premier plan.lnk') "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ps1`" -Surveiller" $ico
  Raccourci (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Audiogrammes.lnk') "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ps1`"" $ico
  Lancer-Surveillance
  [System.Windows.Forms.MessageBox]::Show("Installation terminee.`n`nL'icone Audiogrammes est sur le bureau. La fenetre de l'outil restera toujours au premier plan, meme au-dessus de Doctolib.", "Audiogrammes") | Out-Null
}

# ---------------------------------------------------------------- ouverture de l'outil
Lancer-Surveillance
$deja = [FenetresAudio]::Trouver($titre)
if ($deja.Count -gt 0) { [FenetresAudio]::SetForegroundWindow($deja[0]) | Out-Null; exit 0 }

$chrome = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LocalAppData\Google\Chrome\Application\chrome.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $chrome) {
  [System.Windows.Forms.MessageBox]::Show("Google Chrome est introuvable sur cet ordinateur.", "Audiogrammes") | Out-Null
  exit 1
}

$zone = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$l = 340; $h = [Math]::Min(900, $zone.Height); $x = $zone.Right - $l; $y = $zone.Top

# application installee dans Chrome (icone personnalisee dans la barre des taches) ?
$profil = Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data') -Directory -ErrorAction SilentlyContinue |
  Where-Object { Test-Path (Join-Path $_.FullName "Web Applications\_crx_$appId") } | Select-Object -First 1
if ($profil) {
  Start-Process -FilePath $chrome -ArgumentList "--profile-directory=`"$($profil.Name)`"", "--app-id=$appId"
} else {
  Start-Process -FilePath $chrome -ArgumentList "--app=$url", "--window-size=$l,$h", "--window-position=$x,$y"
}

# placement en haut a droite des que la fenetre apparait (la surveillance la garde au premier plan)
$limite = (Get-Date).AddSeconds(30)
do {
  Start-Sleep -Milliseconds 300
  $f = [FenetresAudio]::Trouver($titre)
} until ($f.Count -gt 0 -or (Get-Date) -gt $limite)
if ($f.Count -gt 0) { [FenetresAudio]::SetWindowPos($f[0], $HWND_TOPMOST, $x, $y, $l, $h, 0x40) | Out-Null }
